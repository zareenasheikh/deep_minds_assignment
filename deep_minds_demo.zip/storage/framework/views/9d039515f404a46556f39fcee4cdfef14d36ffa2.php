<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo $__env->yieldContent('title'); ?></title>
     <?php echo $__env->yieldContent('meta'); ?>


   <link rel="icon" type="image/png" href="<?php echo e(asset('public/img/favicon.jpg')); ?>" sizes="16x16" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

         <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/sweetalert-master/dist/sweetalert.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('public/fonts/icomoon/style.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">


 <?php echo $__env->yieldPushContent('style'); ?>


 <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>">


              <link href="<?php echo e(asset('public/css/toastr.min.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">


     <?php echo $__env->yieldContent('customStyle'); ?>


</head>
<body>
   <?php echo $__env->yieldContent('content'); ?>
    


  <script src="<?php echo e(asset('public/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
        <script src="<?php echo e(asset('public/js/toastr.min.js')); ?>"></script>
      <script src="<?php echo e(asset('public/sweetalert-master/dist/sweetalert.min.js')); ?>"></script>

  <script src="<?php echo e(asset('public/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>

<script async src="<?php echo e(asset('public/js/bootstrap.bundle.min.js')); ?>"></script>
       <?php echo $__env->yieldPushContent('js'); ?>

  <script>
       var baseUrl = <?php echo json_encode(url('/'.Request::segment(2)), 15, 512) ?>;
    var appname = <?php echo json_encode(config('app.name'), 15, 512) ?>;

     <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
        
        case 'warning':
            toastr.warning("<?php echo e(Session::get('message')); ?>");
            break;

        case 'success':
            toastr.success("<?php echo e(Session::get('message')); ?>");
            break;

        case 'error':
            toastr.error("<?php echo e(Session::get('message')); ?>");
            break;
    }
  <?php endif; ?>

  
    </script>


</body>
</html>
<?php /**PATH /home/mandeclan/public_html/deep_minds_zareena_task/resources/views/layouts/app.blade.php ENDPATH**/ ?>