
<?php $__env->startSection('title',"My Monthly Expense List"); ?>
<!-- ................Add meta ................ -->


<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>

<!-- ................custom css................. -->

<?php $__env->startSection('customStyle'); ?>
<style type="text/css">
    .justify-content-between{
    margin-bottom: 20px;
}

.table-bordered .m-auto{

margin-top: 30px;
}

.margin_content{

    margin: 0 auto;
}
</style>
<?php $__env->stopSection(); ?>

<!-- ................Add css link................. -->

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row  mt-5">
       <div class="col-md-8 margin_content" >
        <div class="d-flex justify-content-between" >
            <h3 class="float-start">My Expense (<?php echo e($records->total()); ?>)</h3>
        </div>
        
        <table class="table table-striped table-hover table-bordered m-auto" >
            <thead>
                <tr>
                    <th scope="col">Sr.</th>
                    <th scope="col">Expense Date</th>
                    <th scope="col">Expense Category</th>
                    <th scope="col">Expense Amount</th>
                </tr>
            </thead>
            <tbody>
               <?php if(!empty($records)): ?>

               <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr class="deleteRow">
                <th scope="row"><?php echo e($index+1); ?></th>
                <td><?php echo e(date('d-M-Y',strtotime($data->expense_date))); ?></td>
                <td> <i class="<?php echo e($data->category->category_icon); ?> text-success" aria-hidden="true"></i>   <?php echo e($data->category->category_name); ?></td>
                <td class="m-auto">
                 ₹ <?php echo e($data->expense_amount); ?>

             </td>
             
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
         
     </tbody>
 </table>

</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<!-- ................push new js link................. -->

<?php $__env->startPush('js'); ?>


<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deep_minds_demo\resources\views/frontend/expense/index.blade.php ENDPATH**/ ?>