<script>
    document.addEventListener('DOMContentLoaded', function() {
        $('#calendar-<?php echo e($id); ?>').fullCalendar(<?php echo $options; ?>);
    });
</script>
<?php /**PATH /home/mandeclan/public_html/deep_minds_zareena_task/vendor/asdfx/laravel-fullcalendar/src/Asdfx/LaravelFullcalendar/../../views//script.blade.php ENDPATH**/ ?>