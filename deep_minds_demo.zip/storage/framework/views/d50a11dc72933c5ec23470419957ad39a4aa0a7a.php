<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">


  <link rel="stylesheet" href="<?php echo e(asset('public/fonts/icomoon/style.css')); ?>">

  <link href="<?php echo e(asset('public/fullcalendar/packages/core/main.css')); ?>" rel='stylesheet' />
  <link href="<?php echo e(asset('public/fullcalendar/packages/daygrid/main.css')); ?>" rel='stylesheet' />


  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>">

  <!-- Style -->
  <link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">

  <title>Calendar #10</title>
</head>

<body>


  <div id='calendar-container'>
    <div id='calendar'></div>
  </div>



  <script src="<?php echo e(asset('public/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>

  <script src="<?php echo e(asset('public/fullcalendar/packages/core/main.js')); ?>"></script>
  <script src="<?php echo e(asset('public/fullcalendar/packages/interaction/main.js')); ?>"></script>
  <script src="<?php echo e(asset('public/fullcalendar/packages/daygrid/main.js')); ?>"></script>
  <script src="<?php echo e(asset('public/fullcalendar/packages/timegrid/main.js')); ?>"></script>
  <script src="<?php echo e(asset('public/fullcalendar/packages/list/main.js')); ?>"></script>



  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var calendarEl = document.getElementById('calendar');

      var calendar = new FullCalendar.Calendar(calendarEl, {
        plugins: ['interaction', 'dayGrid', 'timeGrid', 'list'],
        height: 'parent',
        header: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
        },
        defaultView: 'dayGridMonth',
        defaultDate: '2020-06-02',
        navLinks: true, // can click day/week names to navigate views
        editable: true,
        eventLimit: true, // allow "more" link when too many events
        events: [
          {
            title: 'Groceries Rs.205',
            start: '2020-06-02',
          },
          {
            title: 'Transport Rs.205',
            start: '2020-06-05',
          },
          {
            title: 'Transport Rs.205',
            start: '2020-06-20'
          },
          {
            title: 'Entertainment Rs.205',
            start: '2020-06-29'
          }
        ]
      });

      calendar.render();
    });

  </script>

  <script src="<?php echo e(asset('public/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\deep_minds_demo\resources\views/layouts/calendar.blade.php ENDPATH**/ ?>