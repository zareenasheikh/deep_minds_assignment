
<?php $__env->startSection('title',"My Monthly Expense List"); ?>
<!-- ................Add meta ................ -->


<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>

<!-- ................custom css................. -->

<?php $__env->startSection('customStyle'); ?>

<?php $__env->stopSection(); ?>

<!-- ................Add css link................. -->

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

   <div class="container">
   	        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row  mt-5">
        	    <div class="col-md-8" style="margin: 0 auto;">
                <div class="d-flex justify-content-between" style="margin-bottom: 20px;">
                    <h3 class="float-start">My Expense (<?php echo e($records->total()); ?>)</h3>
                </div>
               
                <table class="table table-striped table-hover table-bordered m-auto" style="margin-top: 30px;">
                    <thead>
                        <tr>
                            <th scope="col">Sr.</th>
                              <th scope="col">Expense Date</th>
                            <th scope="col">Expense Category</th>
                            <th scope="col">Expense Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php if(!empty($records)): ?>

                    	<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="deleteRow">
                            <th scope="row"><?php echo e($index+1); ?></th>
                            <td><?php echo e(date('dd-M-Y',strtotime($data->expense_date))); ?></td>
                            <td><?php echo e($data->category->category_name); ?></td>
                            <td class="m-auto">
                               ₹ <?php echo e($data->expense_amount); ?>

                            </td>
                         
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      
                    </tbody>
                </table>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<!-- ................push new js link................. -->

<?php $__env->startPush('js'); ?>


<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mandeclan/public_html/deep_minds_zareena_task/resources/views/frontend/expense/index.blade.php ENDPATH**/ ?>