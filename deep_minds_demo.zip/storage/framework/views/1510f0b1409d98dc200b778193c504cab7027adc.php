<script>
    document.addEventListener('DOMContentLoaded', function() {
        $('#calendar-<?php echo e($id); ?>').fullCalendar(<?php echo $options; ?>);
    });
</script>
<?php /**PATH C:\xampp\htdocs\deep_minds_demo\vendor\asdfx\laravel-fullcalendar\src\Asdfx\LaravelFullcalendar/../../views//script.blade.php ENDPATH**/ ?>