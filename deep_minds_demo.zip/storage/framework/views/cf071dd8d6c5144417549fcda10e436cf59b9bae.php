
<?php $__env->startSection('title',"My Monthly Income List"); ?>
<!-- ................Add meta ................ -->


<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>

<!-- ................custom css................. -->

<?php $__env->startSection('customStyle'); ?>

<?php $__env->stopSection(); ?>

<!-- ................Add css link................. -->

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
  }

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}

.justify-content-between{
    margin-bottom: 20px;
}

.table-bordered .m-auto{

margin-top: 30px;
}

.margin_content{

    margin: 0 auto;
}

</style>

<div class="container">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row  mt-5">
       <div class="col-md-8 margin_content" >
        <div class="d-flex justify-content-between" >
            <h3 class="float-start">My Income (<?php echo e($records->total()); ?>)</h3>
            <button class="btn btn-success float-end  px-3" data-toggle="modal" data-target="#add_income_modal"><i class="fas fa-plus-circle me-2"></i>Add Income</button>
        </div>
        
        <table class="table table-striped table-hover table-bordered m-auto" >
            <thead>
                <tr>
                    <th scope="col">Sr.</th>
                    <th scope="col">Payment Date</th>
                    <th scope="col">Payment Amount</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
               <?php if(!empty($records)): ?>

               <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr class="deleteRow">
                <th scope="row"><?php echo e($index+1); ?></th>
                <td><?php echo e(date('d-m-Y',strtotime($data->date))); ?></td>
                <td class="m-auto">
                 ₹ <?php echo e($data->amount); ?>

             </td>
             <td class="m-auto">
                <button class="btn btn-outline-primary modaleditclick" data-toggle="modal" data-target="#edit_income_modal" id="<?php echo e($data->id); ?>" date="<?php echo e($data->date); ?>" amount="<?php echo e($data->amount); ?>">
                    <i class="far fa-edit"></i>
                </button>
                <button class="btn btn-outline-danger click_disbled" data="<?php echo e($data->id); ?>">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
    </tbody>
</table>

</div>
</div>
</div>


<div class="modal fade" id="edit_income_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <?php echo Form::open(['url'=>['income-update'],'files' => true, 'class' => ' form-bordered form-row-stripped','id' =>'comman_form_id']); ?>


      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Income</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
      
        

      <div class="mb-3">
        <label for="" class="col-form-label">Select Payment Date</label>
        <?php echo Form::date('date',null,array('class'=>'form-control append_date','autocomplete'=>'off','required')); ?> 
    </div>

    <input type="hidden" name="id" value="" class="append_id">
    <div class="mb-3">
        <label for="" class="col-form-label">Payment Amount</label>
        <?php echo Form::number('amount',null,array('class'=>'form-control append_amount','placeholder'=>'Enter Amount','autocomplete'=>'off','required')); ?> 
    </div>

</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-success">Save</button>

</div>

<?php echo e(Form::close()); ?>



</div>
</div>
</div>


<div class="modal fade" id="add_income_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <?php echo Form::open(['url'=>['income'],'files' => true, 'class' => ' form-bordered form-row-stripped','id' =>'comman_form_id']); ?>


      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Income</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
      
        

      <div class="mb-3">
        <label for="" class="col-form-label">Select Payment Date</label>
        <?php echo Form::date('date',null,array('class'=>'form-control','autocomplete'=>'off','required')); ?> 
    </div>

    <div class="mb-3">
        <label for="" class="col-form-label">Payment Amount</label>
        <?php echo Form::number('amount',null,array('class'=>'form-control','placeholder'=>'Enter Amount','autocomplete'=>'off','required')); ?> 
    </div>

</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-success">Update</button>

</div>

<?php echo e(Form::close()); ?>



</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<!-- ................push new js link................. -->

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('public/js/validation.js')); ?>"></script>


<script type="text/javascript">
   $(document).ready(function() {

      $('.modaleditclick').on('click', function(e) {


        $(".append_date").val('')
        $(".append_amount").val('')


        var date=$(this).attr('date');
        var amount=$(this).attr('amount');
        var id=$(this).attr('id');

        
        $(".append_id").val(id)

        $(".append_date").val(date)
        $(".append_amount").val(amount)



    })


  })


   $(".click_disbled").click(function(){


       var data=$(this).attr('data');
       var clickDisbled = $(this);


       var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
       swal({
          title: 'Are you sure?',
          text: "You want to delete this record! ",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
      },
      function() {
          $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

          $.ajax({
           type:"POST",

           url:baseUrl+'/income/delete',
           data:{_token: CSRF_TOKEN, id:data},
           dataType:'JSON',


           complete: function(){
             // window.location.reload();

             clickDisbled.parents('.deleteRow').fadeOut(1500);

             swal(
              'Deleted!',
              'Your record has been deleted.',
              'success'
              );

         }


     });
      });
   });


</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deep_minds_demo\resources\views/frontend/income/index.blade.php ENDPATH**/ ?>